rm -rf /data/openpilot/selfdrive/car/toyota
rm /data/openpilot/opendbc/*.*
rm uninstall.sh