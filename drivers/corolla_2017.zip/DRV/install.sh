mv car/toyota/*.* /data/openpilot/selfdrive/car/toyota
mv dbc/*.* /data/openpilot/opendbc
mv uninstall.sh /data/openpilot
cd .. && rm -rf DRV